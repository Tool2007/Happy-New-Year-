const data_name = [
    {
        ma_ten: "thanh",
        name: "Thanh",
        message: "Hello, I'm Thanh",
        img: "https://vcdn1-giaitri.vnecdn.net/2014/11/12/12-1415753927.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=eeNdzX-KP7izXlmIm_xMCg"
    },
    {
        ma_ten: "thanh",
        name: "Thanh",
        message: "Hello, I'm Thanh",
        img: "https://vcdn1-giaitri.vnecdn.net/2014/11/12/12-1415753927.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=eeNdzX-KP7izXlmIm_xMCg"
    }
]